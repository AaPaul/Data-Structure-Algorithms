 
 This test is implemented by Python.

 There are one class and two individual functions. The class named **RangeList** including all required functions like add, remove and print. The other two functions are **checkList** and **checkListDetails**. The former one is to run the test cases from the file and then print out the results, and another one is to print out the flatten version of interval list.

 I comment out the function named **checkListDetails** as it is a proof  that the list includes all the elements without boundry problems. You can delete the '#' and then you can see the result after you run the file again.
